import { StyleSheet, Text, View, StatusBar, TouchableOpacity, Alert, FlatList } from 'react-native';

// You can import supported modules from npm
import { Card } from 'react-native-paper';

// or any files within the Snack
//import AssetExample from './components/AssetExample';
//https://docs.google.com/spreadsheets/d/10ZgeQfTSs8OI0JB64YiswbIDwGehSgMKNw75UILuz78/edit?gid=1868581049#gid=1868581049
const products =[{id:1, name: 'Ao thun', price:'50000'},
                 {id: 2, name: ' dep', price:'125000'},
                 {id: 3, name:'may tinh', price:'50000000'}];
const App = () => {
  const addToCart = (productName)=>{
    Alert.alert('thong bao','${productName}da duoc them vao gio hang');
  };

const renderProducts = ({Item}) => (
  <View style={styles.productContainer}>
  <View >
    <Text style={styles.productName}>{Item.name}</Text>
    <Text style = {styles.productPrice}>{Item.price}</Text>
  </View>
    <TouchableOpacity style ={styles.addToCartButton} onPress = {() => addToCart(Item.name)}>
    <Text style = {Styles.buttonText}> Them vao gio hang</Text>
</TouchableOpacity>
</View>
);
return(
  <View style ={styles.container}>
  <Text style ={styles.title}Danh sach san pham </Text>
  <FlatList data = {products} keyExtractor ={(Item) => Item.id.toString()}
  renderItem ={renderProductsItem}/>
  </View>
);
};
const styles = StyleSheet.create({container})

